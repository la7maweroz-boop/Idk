package com.v0x7z.adblocker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.v0x7z.adblocker.data.AdBlocklistRepository
import com.v0x7z.adblocker.vpn.V0x7ZVpnService

enum class V2Tab { HOME, STATS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    background = Color(0xFFF4F6F8),
                    surface = Color.White,
                    onBackground = Color(0xFF0F172A),
                    onSurface = Color(0xFF0F172A)
                )
            ) {
                V0x7ZAdBlockerV2App()
            }
        }
    }
}

@Composable
fun V0x7ZAdBlockerV2App() {
    val context = LocalContext.current
    var currentTab by remember { mutableStateOf(V2Tab.HOME) }
    val isVpnActive by AdBlocklistRepository.isServiceRunning.collectAsState()
    val blockedCount by AdBlocklistRepository.blockedCount.collectAsState()
    val blockedByApp by AdBlocklistRepository.blockedByApp.collectAsState()

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == ComponentActivity.RESULT_OK) {
            startV0x7ZVpn(context)
        }
    }

    fun toggleAdBlocker() {
        if (isVpnActive) {
            val stopIntent = Intent(context, V0x7ZVpnService::class.java).apply {
                action = V0x7ZVpnService.ACTION_STOP
            }
            context.startService(stopIntent)
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            val prepareIntent = VpnService.prepare(context)
            if (prepareIntent != null) {
                vpnPermissionLauncher.launch(prepareIntent)
            } else {
                startV0x7ZVpn(context)
            }
        }
    }

    Scaffold(
        containerColor = Color(0xFFF4F6F8),
        bottomBar = {
            NavigationBar(
                containerColor = Color.White,
                tonalElevation = 0.dp
            ) {
                NavigationBarItem(
                    selected = currentTab == V2Tab.HOME,
                    onClick = { currentTab = V2Tab.HOME },
                    icon = { Icon(Icons.Rounded.Home, contentDescription = "Home") },
                    label = { Text("Home") }
                )
                NavigationBarItem(
                    selected = currentTab == V2Tab.STATS,
                    onClick = { currentTab = V2Tab.STATS },
                    icon = { Icon(Icons.Rounded.BarChart, contentDescription = "Stats") },
                    label = { Text("Stats") }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                V2Tab.HOME -> HomeScreen(
                    isVpnActive = isVpnActive,
                    blockedCount = blockedCount,
                    onToggle = ::toggleAdBlocker,
                    onOpenStats = { currentTab = V2Tab.STATS }
                )
                V2Tab.STATS -> StatsScreen(
                    isVpnActive = isVpnActive,
                    blockedCount = blockedCount,
                    blockedByApp = blockedByApp,
                    onGoHome = { currentTab = V2Tab.HOME }
                )
            }
        }
    }
}

@Composable
fun HomeScreen(
    isVpnActive: Boolean,
    blockedCount: Long,
    onToggle: () -> Unit,
    onOpenStats: () -> Unit
) {
    var blockGames by remember { mutableStateOf(true) }
    var blockEmochiAi by remember { mutableStateOf(true) }

    val buttonColor by animateColorAsState(
        targetValue = if (isVpnActive) Color(0xFF047857) else Color(0xFF0F172A),
        animationSpec = tween(durationMillis = 180),
        label = "PowerButtonColor"
    )

    val ringColor by animateColorAsState(
        targetValue = if (isVpnActive) Color(0xFFD1FAE5) else Color(0xFFE2E8F0),
        animationSpec = tween(durationMillis = 180),
        label = "PowerRingColor"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "V0x7Z ad_blocker v2",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (isVpnActive) {
                    "Protection Active · Blocking ads in Games, Emochi AI & Apps"
                } else {
                    "Protection Off · Tap the button below to enable"
                },
                fontSize = 14.sp,
                color = if (isVpnActive) Color(0xFF047857) else Color(0xFF475569),
                textAlign = TextAlign.Center
            )
        }

        // Big Circular Power Button
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(236.dp)
                .clip(CircleShape)
                .background(ringColor)
                .padding(18.dp)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .shadow(elevation = 12.dp, shape = CircleShape)
                    .clip(CircleShape)
                    .clickable { onToggle() },
                shape = CircleShape,
                color = buttonColor
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PowerSettingsNew,
                        contentDescription = if (isVpnActive) "Turn Off Ad Blocker" else "Turn On Ad Blocker",
                        tint = Color.White,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (isVpnActive) "TURN OFF" else "TURN ON",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        letterSpacing = 0.8.sp
                    )
                    Text(
                        text = if (isVpnActive) "Ad Blocker Running" else "Tap to Protect",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                }
            }
        }

        // Summary + Quick Per-App Toggles
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenStats() },
                shape = RoundedCornerShape(16.dp),
                color = Color.White,
                border = BorderStroke(1.dp, Color(0xFFE2E8F0))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.Shield,
                            contentDescription = null,
                            tint = if (isVpnActive) Color(0xFF047857) else Color(0xFF64748B)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Total Ads Blocked", fontSize = 13.sp, color = Color(0xFF64748B))
                            Text(
                                text = blockedCount.toString(),
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )
                        }
                    }
                    Text(
                        text = "View Stats →",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF047857)
                    )
                }
            }

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = Color.White,
                border = BorderStroke(1.dp, Color(0xFFE2E8F0))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Emochi AI App", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            Text("Blocks ad SDKs while keeping chat live", fontSize = 12.sp, color = Color(0xFF64748B))
                        }
                        Switch(
                            checked = blockEmochiAi,
                            onCheckedChange = {
                                blockEmochiAi = it
                                AdBlocklistRepository.setEmochiProtection(it)
                            }
                        )
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = Color(0xFFF1F5F9))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("All Mobile Games", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            Text("Unity Ads, AppLovin, IronSource, Vungle", fontSize = 12.sp, color = Color(0xFF64748B))
                        }
                        Switch(
                            checked = blockGames,
                            onCheckedChange = {
                                blockGames = it
                                AdBlocklistRepository.setGamesProtection(it)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StatsScreen(
    isVpnActive: Boolean,
    blockedCount: Long,
    blockedByApp: Map<String, Long>,
    onGoHome: () -> Unit
) {
    val entries = blockedByApp.entries.sortedByDescending { it.value }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 24.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Blocked Ads Status",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )
                Text(
                    text = if (isVpnActive) "V0x7Z ad_blocker v2 is active" else "Ad blocker is currently off",
                    fontSize = 13.sp,
                    color = if (isVpnActive) Color(0xFF047857) else Color(0xFF64748B)
                )
            }
            TextButton(onClick = onGoHome) {
                Text("Power Switch")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Total Ads Blocked", fontSize = 13.sp, color = Color(0xFF64748B))
                Text(
                    text = blockedCount.toString(),
                    fontSize = 36.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Ads Blocked by App Category",
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF0F172A)
        )
        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(entries) { (appLabel, count) ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = appLabel,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF0F172A)
                        )
                        Text(
                            text = "$count blocked",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF047857)
                        )
                    }
                }
            }
        }
    }
}

private fun startV0x7ZVpn(context: android.content.Context) {
    val intent = Intent(context, V0x7ZVpnService::class.java).apply {
        action = V0x7ZVpnService.ACTION_START
    }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        context.startForegroundService(intent)
    } else {
        context.startService(intent)
    }
}

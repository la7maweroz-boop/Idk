package com.v0x7z.adblocker.vpn

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.v0x7z.adblocker.MainActivity
import com.v0x7z.adblocker.data.AdBlocklistRepository
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.atomic.AtomicBoolean

class V0x7ZVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.v0x7z.adblocker.START"
        const val ACTION_STOP = "com.v0x7z.adblocker.STOP"
        private const val CHANNEL_ID = "v0x7z_vpn_channel"
        private const val NOTIFICATION_ID = 2077
        private const val LOCAL_VPN_IP = "10.77.0.2"
        private const val LOCAL_DNS_IP = "10.77.0.1"
        private const val UPSTREAM_DNS = "1.1.1.1"
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private val running = AtomicBoolean(false)
    private var workerThread: Thread? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return when (intent?.action) {
            ACTION_STOP -> {
                stopVpn()
                START_NOT_STICKY
            }
            else -> {
                startVpn()
                START_STICKY
            }
        }
    }

    private fun startVpn() {
        if (running.getAndSet(true)) return

        createNotificationChannel()
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("V0x7Z ad_blocker v2 is active")
            .setContentText("Blocking ads across Games, Emochi AI & Apps")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .setContentIntent(openAppIntent)
            .build()

        startForeground(NOTIFICATION_ID, notification)

        val builder = Builder()
            .setSession("V0x7Z ad_blocker v2")
            .addAddress(LOCAL_VPN_IP, 32)
            .addDnsServer(LOCAL_DNS_IP)
            .addRoute(LOCAL_DNS_IP, 32)
            .setMtu(1500)

        runCatching { builder.addDisallowedApplication(packageName) }

        vpnInterface = builder.establish()
        AdBlocklistRepository.setRunning(true)

        workerThread = Thread(::runDnsLoop, "V0x7Z-V2-DNS").apply { start() }
    }

    private fun runDnsLoop() {
        val fd = vpnInterface ?: return
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val packetBuffer = ByteArray(32767)

        while (running.get()) {
            val length = try {
                input.read(packetBuffer)
            } catch (_: Exception) {
                break
            }
            if (length <= 0) continue

            handleIpPacket(packetBuffer.copyOf(length), output)
        }
    }

    private fun handleIpPacket(packet: ByteArray, output: FileOutputStream) {
        if (packet.size < 28) return
        val version = (packet[0].toInt() shr 4) and 0x0F
        if (version != 4) return

        val ihl = (packet[0].toInt() and 0x0F) * 4
        val protocol = packet[9].toInt() and 0xFF
        if (protocol != 17) return

        if (packet.size < ihl + 8) return
        val destPort = ((packet[ihl + 2].toInt() and 0xFF) shl 8) or (packet[ihl + 3].toInt() and 0xFF)
        if (destPort != 53) return

        val dnsOffset = ihl + 8
        val dnsPayload = packet.copyOfRange(dnsOffset, packet.size)
        val queryDomain = parseDnsQueryDomain(dnsPayload)

        val blockedCategory = queryDomain?.let { AdBlocklistRepository.matchBlockedCategory(it) }
        val dnsResponse: ByteArray = if (blockedCategory != null) {
            AdBlocklistRepository.recordBlocked(blockedCategory)
            buildNxDomainResponse(dnsPayload)
        } else {
            forwardDnsUpstream(dnsPayload) ?: return
        }

        val replyPacket = buildIpv4UdpReply(packet, ihl, dnsResponse)
        synchronized(output) {
            runCatching { output.write(replyPacket) }
        }
    }

    private fun forwardDnsUpstream(dnsQuery: ByteArray): ByteArray? {
        return try {
            DatagramSocket().use { socket ->
                protect(socket)
                socket.soTimeout = 3000
                val upstreamAddr = InetAddress.getByName(UPSTREAM_DNS)
                socket.send(DatagramPacket(dnsQuery, dnsQuery.size, upstreamAddr, 53))
                val respBuffer = ByteArray(4096)
                val respPacket = DatagramPacket(respBuffer, respBuffer.size)
                socket.receive(respPacket)
                respBuffer.copyOf(respPacket.length)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun parseDnsQueryDomain(dns: ByteArray): String? {
        if (dns.size < 13) return null
        val labels = mutableListOf<String>()
        var idx = 12
        while (idx < dns.size) {
            val len = dns[idx].toInt() and 0xFF
            if (len == 0) break
            if (idx + 1 + len > dns.size) return null
            labels.add(String(dns, idx + 1, len, Charsets.US_ASCII))
            idx += len + 1
        }
        return if (labels.isEmpty()) null else labels.joinToString(".").lowercase()
    }

    private fun buildNxDomainResponse(query: ByteArray): ByteArray {
        val resp = query.copyOf()
        if (resp.size >= 4) {
            resp[2] = ((resp[2].toInt() and 0x79) or 0x80).toByte()
            resp[3] = ((resp[3].toInt() and 0xF0) or 0x83).toByte()
        }
        return resp
    }

    private fun buildIpv4UdpReply(request: ByteArray, ihl: Int, dnsResponse: ByteArray): ByteArray {
        val totalLen = ihl + 8 + dnsResponse.size
        val out = ByteArray(totalLen)
        System.arraycopy(request, 0, out, 0, ihl)

        System.arraycopy(request, 16, out, 12, 4)
        System.arraycopy(request, 12, out, 16, 4)

        out[2] = (totalLen shr 8).toByte()
        out[3] = (totalLen and 0xFF).toByte()
        out[10] = 0
        out[11] = 0
        val ipChecksum = computeChecksum(out, 0, ihl)
        out[10] = (ipChecksum shr 8).toByte()
        out[11] = (ipChecksum and 0xFF).toByte()

        out[ihl] = request[ihl + 2]
        out[ihl + 1] = request[ihl + 3]
        out[ihl + 2] = request[ihl]
        out[ihl + 3] = request[ihl + 1]

        val udpLen = 8 + dnsResponse.size
        out[ihl + 4] = (udpLen shr 8).toByte()
        out[ihl + 5] = (udpLen and 0xFF).toByte()
        out[ihl + 6] = 0
        out[ihl + 7] = 0

        System.arraycopy(dnsResponse, 0, out, ihl + 8, dnsResponse.size)
        return out
    }

    private fun computeChecksum(buf: ByteArray, offset: Int, len: Int): Int {
        var sum = 0
        var i = offset
        while (i < offset + len - 1) {
            sum += ((buf[i].toInt() and 0xFF) shl 8) or (buf[i + 1].toInt() and 0xFF)
            i += 2
        }
        while ((sum shr 16) != 0) {
            sum = (sum and 0xFFFF) + (sum shr 16)
        }
        return sum.inv() and 0xFFFF
    }

    private fun stopVpn() {
        running.set(false)
        AdBlocklistRepository.setRunning(false)
        runCatching { vpnInterface?.close() }
        vpnInterface = null
        workerThread?.interrupt()
        workerThread = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "V0x7Z ad_blocker v2 Protection",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }
}

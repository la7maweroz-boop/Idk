package com.v0x7z.adblocker.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.concurrent.atomic.AtomicBoolean

object AdBlocklistRepository {

    private val _isServiceRunning = MutableStateFlow(false)
    val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

    private val _blockedCount = MutableStateFlow(0L)
    val blockedCount: StateFlow<Long> = _blockedCount.asStateFlow()

    private val _blockedByApp = MutableStateFlow(
        mapOf(
            "Emochi AI" to 0L,
            "Mobile Games" to 0L,
            "Social & Messaging" to 0L,
            "Video & Audio" to 0L,
            "Browsers & WebViews" to 0L
        )
    )
    val blockedByApp: StateFlow<Map<String, Long>> = _blockedByApp.asStateFlow()

    private val blockGames = AtomicBoolean(true)
    private val blockEmochi = AtomicBoolean(true)

    private val allowlist = hashSetOf(
        "api.emochi.ai",
        "chat.emochi.ai",
        "cdn.emochi.ai"
    )

    private val domainToCategory: Map<String, String> = mapOf(
        "ads.emochi.ai" to "emochi",
        "telemetry.emochi.ai" to "emochi",
        "adservice.emochi.app" to "emochi",
        "googleads.g.doubleclick.net" to "emochi",
        "pagead2.googlesyndication.com" to "browsers",
        "adservice.google.com" to "browsers",
        "tpc.googlesyndication.com" to "browsers",
        "unityads.unity3d.com" to "games",
        "ads.unity3d.com" to "games",
        "config.unityads.unity3d.com" to "games",
        "mediation.applovin.com" to "games",
        "d.applovin.com" to "games",
        "rtb.applovin.com" to "games",
        "events.ironsrc.com" to "games",
        "outcome-ssp.supersonicads.com" to "games",
        "ads.vungle.com" to "games",
        "api.vungle.com" to "games",
        "live.chartboost.com" to "games",
        "analytics.mintegral.net" to "games",
        "api-access.pangolin-sdk-toutiao.com" to "games",
        "an.facebook.com" to "social",
        "ads.tiktok.com" to "social",
        "app.adjust.com" to "social",
        "t.appsflyer.com" to "social",
        "imasdk.googleapis.com" to "streaming",
        "ads.inmobi.com" to "streaming",
        "sb.scorecardresearch.com" to "streaming",
        "init.startappexchange.com" to "browsers",
        "bidder.criteo.com" to "browsers",
        "app-measurement.com" to "emochi"
    )

    fun setRunning(active: Boolean) {
        _isServiceRunning.value = active
    }

    fun setGamesProtection(enabled: Boolean) {
        blockGames.set(enabled)
    }

    fun setEmochiProtection(enabled: Boolean) {
        blockEmochi.set(enabled)
    }

    fun matchBlockedCategory(rawDomain: String): String? {
        val domain = rawDomain.trim().lowercase().trimEnd('.')
        if (domain.isEmpty() || allowlist.contains(domain)) return null

        var current = domain
        while (current.isNotEmpty()) {
            val cat = domainToCategory[current]
            if (cat != null) {
                if (cat == "emochi" && !blockEmochi.get()) return null
                if (cat == "games" && !blockGames.get()) return null
                return when (cat) {
                    "emochi" -> "Emochi AI"
                    "games" -> "Mobile Games"
                    "social" -> "Social & Messaging"
                    "streaming" -> "Video & Audio"
                    else -> "Browsers & WebViews"
                }
            }
            val dotIndex = current.indexOf('.')
            if (dotIndex == -1) break
            current = current.substring(dotIndex + 1)
        }
        return null
    }

    fun recordBlocked(appLabel: String) {
        _blockedCount.value = _blockedCount.value + 1L
        _blockedByApp.update { current ->
            val mutable = current.toMutableMap()
            mutable[appLabel] = (mutable[appLabel] ?: 0L) + 1L
            mutable
        }
    }
}

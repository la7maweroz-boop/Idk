# V0x7Z ad_blocker v2 (Android APK Project)

Native Android system-wide DNS ad-blocker built with `VpnService` and Jetpack Compose.

## Option 1: Build APK with Android Studio (Local)

1. Extract this ZIP folder and open it in **Android Studio** (Ladybug or newer).
2. Let Gradle sync.
3. Click **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
4. Copy `app/build/outputs/apk/debug/app-debug.apk` to your Android phone and install it.

## Option 2: Build APK Automatically in the Cloud (No Android Studio Needed)

1. Upload the extracted files to a GitHub repository.
2. Open the **Actions** tab and run **Build V0x7Z ad_blocker v2 APK** (included in `.github/workflows/build-apk.yml`).
3. Download the compiled `V0x7Z-ad_blocker-v2-apk` artifact directly to your Android phone.
